# TO RUN

# Start mongodb
mongod